chmod +x dima.py
cp dima.py /usr/local/bin/dima
